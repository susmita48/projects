import {NgModule} from '@angular/core';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { LoginFormDemo } from './login/login.component';
@NgModule({
exports: [
MatButtonModule,
MatInputModule,

],imports: [ /* add modules here so Angular knows to use them */
BrowserModule,
],providers: [],
declarations:[LoginFormDemo ],
bootstrap: [AppComponent]})

export class AppModule {}